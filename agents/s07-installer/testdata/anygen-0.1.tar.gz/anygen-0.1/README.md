anygen 0.1 — bundled tarball demo for s07
